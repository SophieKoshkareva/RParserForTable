FileReport <- setClass("FileReport",
  slots = c(directory = "character",
           file = "file"),
  contains = "File"
)

setGeneric(name = "setFileReportDirectory",
  def = function(theObject, directory)
  {
    standardGeneric("setFileReportDirectory")
  }
)
setMethod(f = "setFileReportDirectory",
  signature = "File",
  definition = function(theObject, directory)
  {
    theObject@path <- paste(directory, "Report_", format(Sys.time(), "%Y_%m_%d"), ".txt", sep = "")
    return(theObject)
  }
)
setGeneric(name = "OpenFileReport", 
  def = function(theObject)
  {
    standardGeneric("OpenFileReport")
  }
)
setMethod(f = "OpenFileReport",
  signature = "File",
  definition = function(theObject)
  { 
    theObject@file <- file(description = theObject@path, open = "w")
    return(theObject)
  }
)

setGeneric(name = "CloseFileReport", 
  def = function(theObject)
  {
    standardGeneric("CloseFileReport")
  }
)
setMethod(f = "CloseFileReport",
  signature = "File",
  definition = function(theObject)
  { 
    on.exit(close(theObject@file))
    return(theObject)
  }
)